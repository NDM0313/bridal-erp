<?php

return [
    'name' => 'Connector',
    'module_version' => '2.2',
    'pid' => 9,
];